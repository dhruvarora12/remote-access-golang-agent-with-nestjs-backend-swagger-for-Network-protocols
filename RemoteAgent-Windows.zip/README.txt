Remote Agent - Windows Installer
=================================

INSTALLATION INSTRUCTIONS:

Method 1: Using Batch File (Easiest)
-------------------------------------
1. Right-click "install-windows.bat"
2. Select "Run as administrator"
3. Follow the on-screen instructions

Method 2: Using PowerShell
---------------------------
1. Right-click PowerShell
2. Select "Run as administrator"
3. Run: .\install-windows.ps1

Method 3: Manual Installation
------------------------------
1. Copy agent-windows.exe to C:\Program Files\RemoteAgent\
2. Create config.json in C:\ProgramData\RemoteAgent\
3. Run the agent: agent-windows.exe

RUNNING THE AGENT:
------------------
After installation:
1. Open Command Prompt or PowerShell
2. Run: cd "C:\Program Files\RemoteAgent"
3. Run: .\remote-agent.exe

The agent will connect to the server automatically.

UNINSTALLATION:
---------------
1. Stop the agent if running
2. Delete C:\Program Files\RemoteAgent\
3. Delete C:\ProgramData\RemoteAgent\

For support, contact your system administrator.
